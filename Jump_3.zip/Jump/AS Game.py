import pygame

pygame.init()
width, height = 930, 690

map = [
'                               ',
'                               ',
'            XXXXXXX            ',
'            XXXXXXX            ',
'            XXXXXXX            ',
'            XXXXXXX            ',
'                               ',
'                               ',
'                               ',
'                               ',
'                               ',
'                               ',
'XXXXXXXX               XXXXXXXX',
'XXXXXXXX               XXXXXXXX',
'XXXXXXXX               XXXXXXXX',
'XXXXXXXX               XXXXXXXX',
'XXXXXXXX               XXXXXXXX',
'XXXXXXXX               XXXXXXXX',
'XXXXXXXX               XXXXXXXX',
'XXXXXXXXP              XXXXXXXX',
'XXXXXXXX               XXXXXXXX',
'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX',
'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX']
tile_size = 30

black = (0, 0, 0)
grey = (127, 127, 127)
red = (255, 0, 0)

window = pygame.display.set_mode((width, height))
pygame.display.set_caption("GAME")

clock = pygame.time.Clock()


run = True

class Tile(pygame.sprite.Sprite):
    def __init__(self, pos, size):
        super().__init__()
        self.image = pygame.Surface((size, size))
        self.image.fill(grey)
        self.rect = self.image.get_rect(topleft = pos)

class Player(pygame.sprite.Sprite):
    def __init__(self, pos):
        super().__init__()
        self.image = pygame.Surface((50, 60))
        self.image.fill(red)
        self.rect = self.image.get_rect(topleft = pos)
        
        self.direction = pygame.math.Vector2(0, 0)
        self.speed = 3
        self.gravity = 0.8
        self.jump_speed = -16
        
    def get_input(self):
        keys = pygame.key.get_pressed()
        
        if keys[pygame.K_RIGHT]:
            self.direction.x = 1
        elif keys[pygame.K_LEFT]:
            self.direction.x = -1
        else:
            self.direction.x = 0
        
        if keys[pygame.K_SPACE]:
            self.jump()
    
    def apply_gravity(self):
        self.direction.y += self.gravity
        self.rect.y += self.direction.y
    
    def jump(self):
        self.direction.y = self.jump_speed
    
    def update(self):
        self.get_input()

class Level:
    def __init__(self, level_data, surface):
        
        self.display_surface = surface
        self.setup_level(level_data)

    def setup_level(self, layout):
        self.tiles = pygame.sprite.Group()
        self.player = pygame.sprite.GroupSingle()
        
        for row_index, row in enumerate(layout):
            for col_index, cell in enumerate(row):
                x = col_index * tile_size
                y = row_index * tile_size
                
                if cell == "X":
                    tile = Tile((x, y), tile_size)
                    self.tiles.add(tile)
                if cell == "P":
                    player_sprite = Player((x, y))
                    self.player.add(player_sprite)

    def horizontal_movement_collision(self):
        player = self.player.sprite
        player.rect.x += player.direction.x * player.speed
        
        for sprite in self.tiles.sprites():
            if sprite.rect.colliderect(player.rect):
                if player.direction.x < 0:
                    player.rect.left = sprite.rect.right
                elif player.direction.x > 0:
                    player.rect.right = sprite.rect.left
                    
    def vertical_movement_collision(self):
        player = self.player.sprite
        player.apply_gravity()
        
        for sprite in self.tiles.sprites():
            if sprite.rect.colliderect(player.rect):
                if player.direction.y > 0:
                    player.rect.bottom = sprite.rect.top
                    player.direction.y = 0
                elif player.direction.y < 0:
                    player.rect.top = sprite.rect.bottom
                    player.direction.y = 0

    def run(self):
        self.tiles.draw(self.display_surface)
        
        self.player.update()
        self.horizontal_movement_collision()
        self.vertical_movement_collision()
        self.player.draw(self.display_surface)

level = Level(map, window)
        

while run:
    clock.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    window.fill(black)
    level.run()

    pygame.display.update()